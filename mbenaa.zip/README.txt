Make Building Energy Nodes Awesome Again (MBENAA)

This mod enables an experimental building mode flag which changes the building mode of Energy Nodes so that they can be built by clicking-and-dragging.
This has the following effects:
- automatically places power nodes at max distance from the previous one when LMB is held.

Mod created by Vandragorax#8025