BRUTAL 5-HOUR LONG SURVIVAL MOD

5-hour long mission on brutal with an extreme sword and blaster so that you don't die like a fly being swatted.
30 minutes of warm up time and 10 minutes attack intervals.

INSTALL REQUIREMENTS
In the Riftbreaker's packs folder, remove all 3rd party zips except the original files from the game. then add
this mod there.

HOW TO PLAY
1. Go to the Survival menu.
2. Select "Custom" but do "NOT" click "Confirm". The mission duration has been set to 5-hours.
3. Escape and start the mission.

TO CHANGE MAP TO BENCHMARK INTENSE
1. Edit the file missions\survival\jungle.mission in 5_hour_brutal_survival.zip.
2. Remark the test_prologue map and enable benchmark_intense.

Like this:

//    biomes "jungle"
//    required_tiles "biomes/legacy_maps/tiles/test_prologue/test_prologue.tile"
//-------------------------------------------------------------------
    biomes "legacy_maps"
    required_tiles "biomes/legacy_maps/tiles/benchmark_intense/benchmark_intense.tile"