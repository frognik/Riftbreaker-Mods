Electro Pipes
Version 0.1

Goals of this mod:
1) Make pipes distributing energy.
2) Have fun :)

Change log:
V0.1
Pipes now distribut energy in 1 tile radius

Note: This mode in no way balanced and made just for fun :)