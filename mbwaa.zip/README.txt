Make Building Walls Awesome Again (MBWAA)

This mod enables an experimental building mode flag which changes the building mode of Walls so that they can be built by clicking-and-dragging.
This has the following effects:
- automatically builds long sections of walls without having to place each one individually when LMB is held.

Mod created by Vandragorax#8025