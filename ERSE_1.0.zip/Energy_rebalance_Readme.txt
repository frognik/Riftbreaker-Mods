Energy rebalance mod 
Version 0.2
by ShadowAngel
Compatible game version: SVN_12924.TC_178

Goals of this rebalance:
1) Make it viable to use outposts not connected to your main base.
2) Add variety to base energy generation methods.
3) Make it so using more powerful or upgraded versions of building is always better then building new ones.
4) Best energy generation should be liquid > raw resources > free energy

Change log:
V0.2
wind_turbine_l2 - Carbonium  60 => 15, Ironinum 5 => 3
wind_turbine_l3 - Carbonium  120 => 15, Ironinum 20 => 3
carbonium_powerplant - Carbonium  75 => 100, Power output 100 => 125
carbonium_powerplant_l2 - Carbonium  60 => 50, Power output 200 => 250
carbonium_powerplant_l3 - Carbonium  120 => 50, Power output 400 => 500
geothermal_powerplant Carbonium  75 => 70, Ironinum 25 => 50
geothermal_powerplant_l2 Carbonium  150 => 35, Ironinum 50 => 25
geothermal_powerplant_l3 Carbonium  300 => 35, Ironinum 100 => 25
animal_biomass_powerplant Carbonium  150 => 140, Ironinum 50 => 100
animal_biomass_powerplant_l2 Carbonium  300 => 70, Ironinum 100 => 50
animal_biomass_powerplant_l3 Carbonium  600 => 70, Ironinum 200 => 50
plant_biomass_powerplant Carbonium  100 => 95, Ironinum 20 => 50
plant_biomass_powerplant Carbonium  200 => 48, Ironinum 40 => 25
plant_biomass_powerplant Carbonium  400 => 48, Ironinum 80 => 25
gas_powerplant Carbonium 100 => 200, Power output 800 => 750
gas_powerplant_l2 Carbonium 200 => 100, Ironinum 200 => 100, Power output 1600 => 1500
gas_powerplant_l3 Carbonium 400 => 100, Ironinum 400 => 100, Power output 3200 => 3000
magma_powerplant Carbonium 400 => 300
fusion_powerplant Carbonium 400 => 300, Ironinum 300 => 400, Power output 3500 => 5000
nuclear_powerplant Carbonium 300 => 200

V0.1
wind_turbine - Carbonium  50 => 30, Ironinum 0 => 5, Power output 6 => 13
wind_turbine_l2 - Carbonium  100 => 60, Ironinum 0 => 10, Power output 12 => 26
wind_turbine_l3 - Carbonium  200 => 120, Ironinum 0 => 20, Power output 24 => 52
carbonium_powerplant - Carbonium  50 => 75, Power output 50 => 100
carbonium_powerplant_l2 - Carbonium  100 => 60, Power output 100 => 200
carbonium_powerplant_l3 - Carbonium  200 => 120, Power output 150 => 400
geothermal_powerplant Carbonium  600 => 75, Ironinum 400 => 25,Power output  200 => 250
geothermal_powerplant_l2 Carbonium  1200 => 150, Ironinum 800 => 50,Power output  400 => 500
geothermal_powerplant_l3 Carbonium  2400 => 300, Ironinum 1600 => 100,Power output  800 => 1000
animal_biomass_powerplant Power output 50 =>  425
animal_biomass_powerplant_l2 Power output 100 => 850
animal_biomass_powerplant_l3 Power output 200 => 1700
plant_biomass_powerplant Power output 50 =>  160
plant_biomass_powerplant Power output 100 => 320
plant_biomass_powerplant Power output 200 => 640
gas_powerplant Carbonium 400 => 100, Ironinum 300 => 200, Power output 500 => 800
gas_powerplant_l2 Carbonium 800 => 200, Ironinum 600 => 400, Power output 1000 => 1600
gas_powerplant_l3 Carbonium 1600 => 400, Ironinum 1200 => 800, Power output 2000 => 3200
magma_powerplant Power output 1000 => 1425
nuclear_powerplant Carbonium 400 => 300, Ironinum 300 => 200, Power output 1500 => 1800, uranium intake 4 => 2

How to install this mod:
1) Install 7z. Other archivers will corrupt your data files.
2) Extract my archive wherever you want.
3) Go into game install folder and into packs folder. Make a backup of 00_win_data.zip. Then open 00_win_data.zip with 7z. (Do not extract it!) 
4) Drag entities folder from my archive in to 7Z window with 00_win_data.zip opened. This should install it automatically. 

Notes:
This time i concentrated on brining all generators building and upgrade costs to baseline of solar panel, plus as testing has shown old qudratic progression model was not working for building upgrades.
So now every update is half cost of building it self. Geting lvl 3 building will yeald 4x energy per x2 building cost and x1 footprint cost.
Complex energy produciers still need more data inserted in to math model. This will be done in version 0.3. Happy playing. PS. Hope @EXORStuff traking this mod. Otherwise its gonna be just a good traing for me as thecnincal game designer x). (Not that i mind more trining. :P )