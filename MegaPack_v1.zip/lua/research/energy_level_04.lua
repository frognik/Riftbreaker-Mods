class 'research' ( LuaGraphNode )

function research:__init()
    LuaGraphNode.__init(self,self)
end

function research:init()
end

function research:IsReadyForResearch()
	return (PlayerService:GetEnergyLvl( 0 ) >= 2 )
end

function research:OnResearchAcquired()
end

return research